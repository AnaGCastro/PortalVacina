package br.com.nava.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import br.com.nava.entity.VacinacaoEntity;

public interface VacinacaoRepository  extends JpaRepository<VacinacaoEntity, Integer>{
	@Query("select u from VacinacaoEntity u where lower(u.usuario) like lower(concat('%', :usuario,'%'))")
	List<VacinacaoEntity> findNomeContainingIgnoreCase(@Param("usuario")String usuario);
}

