package br.com.nava.dtos;

import org.modelmapper.ModelMapper;


import br.com.nava.entity.VacinacaoEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class VacinacaoDTO {
	
	private int id;
	private String usuario;
	private String vacina;
	private String dataAplic;
	private int numDose;
	private String proxDataDose;
	
public VacinacaoEntity toEntity() {
		
		ModelMapper mapper = new ModelMapper();
		
		return mapper.map(this, VacinacaoEntity.class);
	}

}
