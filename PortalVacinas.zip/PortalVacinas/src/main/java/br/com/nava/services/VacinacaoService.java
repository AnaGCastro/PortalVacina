package br.com.nava.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import br.com.nava.dtos.VacinacaoDTO;
import br.com.nava.entity.VacinacaoEntity;
import br.com.nava.repositories.VacinacaoRepository;

@Service
public class VacinacaoService {
	
	
	@Autowired
	VacinacaoRepository vacinacaoRepository;

	public List<VacinacaoDTO> getAll() {

		List<VacinacaoEntity> listaEntity = vacinacaoRepository.findAll();

		List<VacinacaoDTO> listaDTO = new ArrayList<>();

		for (VacinacaoEntity entity : listaEntity) {
			listaDTO.add(entity.toDTO());

		}

		return listaDTO;
	}

	public VacinacaoDTO getOne(Integer id) {
		Optional<VacinacaoEntity> optional = vacinacaoRepository.findById(id);
		VacinacaoEntity vacinacao = optional.orElse(new VacinacaoEntity());
		return vacinacao.toDTO();
	}

	public VacinacaoDTO save(VacinacaoEntity vacinacao) {
		return this.vacinacaoRepository.save(vacinacao).toDTO();

	}
	
	public VacinacaoDTO update(int id, VacinacaoEntity novaVacinacao) {
		Optional<VacinacaoEntity> optional = vacinacaoRepository.findById(id);

		if (optional.isPresent()) {
			VacinacaoEntity vacinacao = optional.get();

			vacinacao.setUsuario(novaVacinacao.getUsuario());
			vacinacao.setVacina(novaVacinacao.getVacina());
			vacinacao.setDataAplic(novaVacinacao.getDataAplic());
			vacinacao.setNumDose(novaVacinacao.getNumDose());
			vacinacao.setProxDataDose(novaVacinacao.getProxDataDose());
			
			return vacinacaoRepository.save(vacinacao).toDTO();
		} else {
			return new VacinacaoEntity().toDTO();
		}
	}
	
	public List<VacinacaoDTO>getByNome(String nome) {
		List<VacinacaoEntity> listaEntity = vacinacaoRepository.findNomeContainingIgnoreCase(nome);
		List<VacinacaoDTO> listaDTO = new ArrayList<>();
		for (VacinacaoEntity entity : listaEntity) {
			listaDTO.add(entity.toDTO());
		}
		return listaDTO;
	}
		
		
	}
	


