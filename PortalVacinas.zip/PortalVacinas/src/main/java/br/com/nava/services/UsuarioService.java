package br.com.nava.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.nava.dtos.UsuarioDTO;
import br.com.nava.entity.UsuarioEntity;
import br.com.nava.repositories.UsuarioRepository;

@Service
public class UsuarioService {
	
	@Autowired
	UsuarioRepository usuarioRepository;

	public List<UsuarioDTO> getAll() {

		List<UsuarioEntity> listaEntity = usuarioRepository.findAll();

		List<UsuarioDTO> listaDTO = new ArrayList<>();

		for (UsuarioEntity entity : listaEntity) {
			listaDTO.add(entity.toDTO());
		}

		return listaDTO;
	}

	public UsuarioDTO getOne(Integer id) {
		Optional<UsuarioEntity> optional = usuarioRepository.findById(id);
		UsuarioEntity usuario = optional.orElse(new UsuarioEntity());
		return usuario.toDTO();
	}

	public UsuarioDTO save(UsuarioEntity usuario) {
	
		return this.usuarioRepository.save(usuario).toDTO();

	}

	public UsuarioDTO update(int id, UsuarioEntity novoUsuario) {
		Optional<UsuarioEntity> optional = usuarioRepository.findById(id);

		if (optional.isPresent()) {
			UsuarioEntity usuario = optional.get();

			usuario.setNome(novoUsuario.getNome());
			usuario.setCpf(novoUsuario.getCpf());
			usuario.setDataNasc(novoUsuario.getDataNasc());
			usuario.setEndereco(novoUsuario.getEndereco());
			usuario.setTelefone(novoUsuario.getTelefone());

			return usuarioRepository.save(usuario).toDTO();
		} else {
			return new UsuarioEntity().toDTO();
		}

	}

	public void delete(int id) {
		usuarioRepository.deleteById(id);
	}
	
	public List<UsuarioDTO>getByCpf(String cpf) {
		List<UsuarioEntity> listaEntity = usuarioRepository.findCpfContainingIgnoreCase(cpf);
		List<UsuarioDTO> listaDTO = new ArrayList<>();
		for (UsuarioEntity entity : listaEntity) {
			listaDTO.add(entity.toDTO());
		}
		return listaDTO;
	}

}
