package br.com.nava.dtos;



import org.modelmapper.ModelMapper;

import br.com.nava.entity.VacinaEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor

public class VacinaDTO {
	
	private int id;
	private String nome;
	private String fabricante;
	private int qtdDeDoses;
	private String intervaloDoses;

public VacinaEntity toEntity() {
		
		ModelMapper mapper = new ModelMapper();
		
		return mapper.map(this, VacinaEntity.class);
	}

}
