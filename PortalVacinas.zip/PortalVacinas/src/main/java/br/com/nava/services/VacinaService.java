package br.com.nava.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.nava.dtos.VacinaDTO;
import br.com.nava.entity.VacinaEntity;
import br.com.nava.repositories.VacinaRepository;

@Service
public class VacinaService {

	@Autowired
	VacinaRepository vacinaRepository;

	public List<VacinaDTO> getAll() {

		List<VacinaEntity> listaEntity = vacinaRepository.findAll();

		List<VacinaDTO> listaDTO = new ArrayList<>();

		for (VacinaEntity entity : listaEntity) {
			listaDTO.add(entity.toDTO());

		}

		return listaDTO;
	}

	public VacinaDTO getOne(Integer id) {
		Optional<VacinaEntity> optional = vacinaRepository.findById(id);
		VacinaEntity vacina = optional.orElse(new VacinaEntity());
		return vacina.toDTO();
	}

	public VacinaDTO save(VacinaEntity vacina) {
		return this.vacinaRepository.save(vacina).toDTO();

	}

	public VacinaDTO update(int id, VacinaEntity novaVacina) {
		Optional<VacinaEntity> optional = vacinaRepository.findById(id);

		if (optional.isPresent()) {
			VacinaEntity vacina = optional.get();

			vacina.setNome(novaVacina.getNome());
			vacina.setFabricante(novaVacina.getFabricante());
			;
			vacina.setQtdDeDoses(novaVacina.getQtdDeDoses());
			vacina.setIntervaloDoses(novaVacina.getIntervaloDoses());

			return vacinaRepository.save(vacina).toDTO();
		} else {
			return new VacinaEntity().toDTO();
		}
	}
	
	public void delete(int id) {
		vacinaRepository.deleteById(id);
	}
	
	public List<VacinaDTO>getByNome(String nome) {
		List<VacinaEntity> listaEntity = vacinaRepository.findNomeContainingIgnoreCase(nome);
		List<VacinaDTO> listaDTO = new ArrayList<>();
		for (VacinaEntity entity : listaEntity) {
			listaDTO.add(entity.toDTO());
		}
		return listaDTO;
	}
}
