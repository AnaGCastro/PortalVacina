package br.com.nava.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import br.com.nava.entity.VacinaEntity;

public interface VacinaRepository extends JpaRepository<VacinaEntity, Integer> {
	
	@Query("select u from VacinaEntity u where lower(u.nome) like lower(concat('%', :nome,'%'))")
	List<VacinaEntity> findNomeContainingIgnoreCase(@Param("nome")String nome);
}
