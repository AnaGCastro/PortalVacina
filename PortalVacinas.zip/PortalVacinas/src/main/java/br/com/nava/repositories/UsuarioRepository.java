package br.com.nava.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import br.com.nava.entity.UsuarioEntity;

public interface UsuarioRepository  extends JpaRepository<UsuarioEntity, Integer>{
	@Query("select u from UsuarioEntity u where lower(u.cpf) like lower(concat('%', :cpf,'%'))")
	List<UsuarioEntity> findCpfContainingIgnoreCase(@Param("cpf")String cpf);

}
